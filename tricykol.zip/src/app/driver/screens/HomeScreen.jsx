
import React from 'react';
import DriverDashboard from '@app/driver/DriverDashboard';

const HomeScreen = () => {
  return <DriverDashboard />;
};

export default HomeScreen;
